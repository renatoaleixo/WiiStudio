# Padrões
Async, nullable, SOLID.