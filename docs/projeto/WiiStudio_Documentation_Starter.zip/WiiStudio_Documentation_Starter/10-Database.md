# SQLite
Configurações e histórico.