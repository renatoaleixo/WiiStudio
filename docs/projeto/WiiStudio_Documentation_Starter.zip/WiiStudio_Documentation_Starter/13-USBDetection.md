# USB
Detecção automática.