# Entidades
Game
Settings
History