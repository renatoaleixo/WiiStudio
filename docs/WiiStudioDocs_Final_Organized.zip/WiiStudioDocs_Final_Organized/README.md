# WiiStudio

WiiStudio é uma aplicação desktop cross-platform para gerenciamento de biblioteca de jogos Wii, dispositivos, importação, conversão, metadados, assets, diagnósticos, plugins e operações relacionadas.

O projeto utiliza .NET, Avalonia UI, Clean Architecture, MVVM, SQLite, Serilog e integração segura com ferramentas externas como Wiimms ISO Tools.

---

# Objetivos

- Gerenciar biblioteca local de jogos Wii.
- Detectar e consultar dispositivos USB.
- Importar arquivos ISO, WBFS, RVZ e NKit.
- Converter jogos usando ferramentas externas seguras.
- Baixar e armazenar metadados e capas.
- Exibir diagnósticos e logs.
- Executar tarefas longas com progresso e cancelamento.
- Suportar plugins com permissões explícitas.
- Manter UI moderna, responsiva e acessível.

---

# Stack

- .NET 9
- C# 13
- Avalonia UI
- MVVM
- CommunityToolkit.Mvvm
- Clean Architecture
- Dependency Injection
- SQLite
- Serilog
- xUnit
- FluentAssertions
- Wiimms ISO Tools
- Plugin SDK

---

# Arquitetura

```text
UI
 ↓
Application
 ↓
Domain
 ↓
Infrastructure
```

## Regras

- Domain não depende de Infrastructure ou UI.
- Application define casos de uso e contratos.
- Infrastructure implementa integrações externas.
- UI usa MVVM.
- Code-behind não deve conter regra de negócio.
- Processos externos passam por `IProcessRunner`.
- Plugins passam por manifesto, permissões e isolamento.

---

# Estrutura Esperada

```text
src/
├── WiiStudio.Domain/
├── WiiStudio.Application/
├── WiiStudio.Infrastructure/
├── WiiStudio.UI/
├── WiiStudio.Plugin.Abstractions/
├── WiiStudio.Plugin.Hosting/
├── WiiStudio.Plugin.Security/
└── WiiStudio.Plugin.Diagnostics/

tests/
├── WiiStudio.Domain.Tests/
├── WiiStudio.Application.Tests/
├── WiiStudio.Infrastructure.Tests/
├── WiiStudio.UI.Tests/
├── WiiStudio.Plugin.Tests/
├── WiiStudio.Integration.Tests/
└── WiiStudio.Performance.Tests/
```

---

# Documentação Principal

Leia primeiro:

1. `AI_CONTEXT.md`
2. `DOCUMENT_INDEX.md`
3. `001-Architecture.md`
4. `002-SolutionStructure.md`
5. `003-CodingStandards.md`
6. `ROADMAP.md`

---

# Funcionalidades Planejadas

## Biblioteca

- Scan de biblioteca.
- Detalhes do jogo.
- Favoritos.
- Busca e filtros.
- Detecção de duplicados.
- Remoção segura.

## Dispositivos

- Detecção USB.
- Device Manager.
- Diagnóstico de permissões.
- Integração com Wiimms.

## Importação e Conversão

- Import ISO.
- Import WBFS.
- Import RVZ.
- Import NKit.
- Batch Conversion.
- Exportação.
- Verificação de integridade.

## Metadados e Assets

- GameTDB.
- Cache offline.
- Capas.
- Banners.
- Disc arts.
- Providers futuros.

## Operações

- Task Manager.
- Notification Center.
- Logging Center.
- Advanced Diagnostics.
- Backup/Restore.
- Update Manager.

## Plugins

- Plugin SDK.
- Manifest.
- Discovery.
- Loading.
- Permissions.
- UI Extensions.
- Metadata Providers.
- Conversion Providers.
- Diagnostics.

---

# Regras Importantes

## Processos Externos

Nunca usar `Process.Start` diretamente.

Use sempre:

```text
IProcessRunner
```

Motivos:

- segurança;
- timeout;
- cancelamento;
- captura de logs;
- redaction;
- integração com Task Manager.

## Wiimms

Wiimms é a engine oficial para operações WBFS.

Não implementar WBFS manualmente.

## NKit

NKit é uma ferramenta externa legado.

Não implementar algoritmo NKit internamente.

## Plugins

Plugins devem:

- possuir `plugin.json`;
- declarar permissões;
- passar por validação;
- ter falhas isoladas;
- não acessar serviços internos sem contrato.

---

# Segurança

O projeto deve seguir:

- `F081-SecurityFoundation.md`
- `F083-ExternalProcessSecurity.md`
- `F086-SafePathHandling.md`
- `F088-LogRedaction.md`
- `F090-SecurityChecklist.md`

Regras críticas:

- validar entrada externa;
- normalizar paths;
- bloquear path traversal;
- redigir secrets;
- confirmar ações destrutivas;
- usar permissões explícitas.

---

# Testes

Padrão:

- xUnit;
- FluentAssertions;
- Arrange/Act/Assert;
- mocks/fakes;
- banco temporário;
- diretórios temporários;
- fake ProcessRunner;
- regressão para bugs.

Documentos:

- `F091-TestingStrategy.md`
- `F092-UnitTestingStandards.md`
- `F093-IntegrationTestingStandards.md`
- `F100-QualityGates.md`

---

# Como Desenvolver uma Feature

1. Ler `AI_CONTEXT.md`.
2. Encontrar a feature em `DOCUMENT_INDEX.md`.
3. Ler dependências.
4. Implementar respeitando Clean Architecture.
5. Criar testes.
6. Aplicar Security Checklist quando aplicável.
7. Atualizar documentação.
8. Validar Quality Gates.

---

# Comandos Esperados

Exemplos futuros:

```bash
dotnet restore
dotnet build
dotnet test
dotnet run --project src/WiiStudio.UI
```

---

# Definition of Done

Uma feature só deve ser considerada pronta quando:

- requisitos atendidos;
- testes criados;
- erros tratados;
- logs seguros;
- UI com estados;
- acessibilidade básica;
- documentação atualizada;
- Quality Gates aprovados.

---

# Status

Projeto em fase de documentação e preparação de implementação.
